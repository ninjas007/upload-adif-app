<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RulesAward extends Model
{
 	
}
