<!DOCTYPE html>
<html>
<head>
    <title>Member YB6DXC</title>
</head>
<body style="font-size: 14px; text-align: center;">
    <h1>{{ $data['callsign'] }}</h1>
 	<p>{{ $data['nama'] }}</p>
 	<p>{{ $data['no_hp'] }}</p>
 	<p>{{ $data['alamat'] }}</p>
 	<p>{{ $data['kategori'] }}</p>
</body>
</html>