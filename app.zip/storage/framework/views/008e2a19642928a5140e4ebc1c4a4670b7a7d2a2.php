<?php $__env->startSection('content'); ?>
<p style="font-size: 20px" class="text-center border p-1">Awards</p>
<div class="row">
    <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-3">
        <!-- Card -->
        <div class="card">
            <!-- Card image -->
            <a href="<?php echo e($award->url_award); ?>" target="_blank">
                <div class="view overlay">
                    <img class="card-img-top img-fluid" src="<?php echo e($award->url_gambar); ?>" alt="<?php echo e($award->nama); ?>" style="height: 180px;">
                    <div class="mask rgba-white-slight"></div>
                </div>
            </a>
            <!-- Card content -->
            <div class="card-body text-center">
                <p class="card-title fon-weight-bold"><?php echo e($award->nama); ?></p>
                <?php if($award->category == 'premium'): ?>
                <p class="card-text text-success">Category : <?php echo e(ucfirst($award->category)); ?></p>
                <?php elseif($award->category == 'All member'): ?>
                <p class="card-text text-default">Category : All Member</p>
                <?php else: ?>
                <p class="card-text text-primary">Category : <?php echo e(ucfirst($award->category)); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-12">
        <?php echo e($awards->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/welcome/awards.blade.php ENDPATH**/ ?>