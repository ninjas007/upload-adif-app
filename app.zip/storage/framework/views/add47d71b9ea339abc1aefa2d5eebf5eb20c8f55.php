

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-white bg-danger font-weight-bold">Award</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                  <?php echo e(session()->get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('error')): ?>
                                <div class="alert alert-danger alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                  <?php echo e(session()->get('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <a href="<?php echo e(route('admin/award-tambah')); ?>" class="btn btn-success mb-3">Tambah Award</a>
                            <table class="table table-bordered" id="myTable">
                                <thead>
                                    <tr>
                                        <th>Award</th>
                                        <th>Category</th>
                                        <th>Image</th>
                                        <th width="180" class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script type="text/Javascript">
    $(function() {
        $.noConflict();
        // $('#myTable').DataTable();

        $('#myTable').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
                     "url": BASE_URL+"/admin/jsonAwardsMember",
                     "dataType": "json",
                     "type": "POST",
                     "data":{ _token: "<?php echo e(csrf_token()); ?>"}
                   },
            "columns": [
                { "data": "award" },
                { "data": "category" },
                { "data": "image" },
                { "data": "action" }
            ],
            "columnDefs" : [
                {
                    "targets": -2,
                    "className": 'text-center'
                },
                {
                    "targets": -1,
                    "className": 'text-center'
                }
            ]
        });

    })
</script>
<?php $__env->stopSection(); ?>

 

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/admin/award/index.blade.php ENDPATH**/ ?>