<!DOCTYPE html>
<html>
<head>
    <title>Member YB6DXC</title>
</head>
<body style="font-size: 14px; text-align: center;">
    <h1><?php echo e($data['callsign']); ?></h1>
 	<p><?php echo e($data['nama']); ?></p>
 	<p><?php echo e($data['no_hp']); ?></p>
 	<p><?php echo e($data['alamat']); ?></p>
 	<p><?php echo e($data['kategori']); ?></p>
</body>
</html><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/emails/upload_file.blade.php ENDPATH**/ ?>