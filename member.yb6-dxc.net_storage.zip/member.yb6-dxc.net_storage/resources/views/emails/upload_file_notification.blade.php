<!DOCTYPE html>
<html>
<head>
    <title>Notification Send File YB6-DXCommunity</title>
</head>
<body style="font-size: 14px;">
 	<p>Hi, {{ $data['nama'] }}</p>
 	<p>QSO LOGS was Successfully Updated from ADIF to Database, And your award application has been completed automatically.</p>
	<p>Attention :</p>
	<p>"Please always check and log in to your member account to see eligible award claims within a maximum of 7 working days from uploading your QSO file. The eligible award claim will be in your member account automatically"</p>
 	<p>73</p>
 	<p>IT YB6_DXCommunity</p>
</body>
</html>