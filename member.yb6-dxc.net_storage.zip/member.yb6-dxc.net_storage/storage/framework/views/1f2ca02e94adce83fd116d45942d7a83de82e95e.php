<!DOCTYPE html>
<html>
<head>
    <title>Info Expired Member</title>
    <style>
    	table tr td {
    		padding: 5px;
    	}
    </style>
</head>
<body style="font-size: 14px;">
	<div>Hello Admin, Berikut daftar member yang expired hari ini</div>
	<table border="1" style="margin-top: 20px">
		<tr>
			<td>No</td>
			<td>Nama</td>
			<td>Kategori</td>
			<td>No Hp</td>
			<td>Callsign</td>
		</tr>
		<?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e(++$key); ?></td>
				<td><?php echo e($user['name']); ?></td>
				<td><?php echo e($user['category']); ?></td>
				<td><?php echo e($user['no_hp']); ?></td>
				<td><?php echo e($user['callsign']); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
    <h1>Total : <?php echo e($data['count']); ?></h1>
</body>
</html><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/emails/notif_expired_admin.blade.php ENDPATH**/ ?>