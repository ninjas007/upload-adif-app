<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-white bg-danger font-weight-bold">Banner</div>
                <div class="card-body" id="content">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                          <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                          <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-bordered text-center" id="myTable" >
                        <thead>
                            <tr>
                                <th>Nama banner</th>
                                <th>Image</th>
                                <th>Update</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($banners) == 0): ?>
                            <tr><td colspan="6" style="text-align: center;">Tidak ada data</td></tr>
                            <?php endif; ?>
                            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($banner->name); ?></td>
                                <td>
                                    <a href="<?php echo e($banner->url_image); ?>" target="_blank"><img src="<?php echo e($banner->url_image); ?>" width="100"></a>
                                </td>
                                <td>
                                    <a href="/admin/banner/edit/<?php echo e($banner->id); ?>" class="btn btn-primary btn-sm modal-update">Edit</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/admin/banner/index.blade.php ENDPATH**/ ?>