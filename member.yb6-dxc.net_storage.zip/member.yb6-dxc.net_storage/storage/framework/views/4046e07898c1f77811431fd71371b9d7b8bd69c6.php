<?php echo e($slot); ?>

<?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>