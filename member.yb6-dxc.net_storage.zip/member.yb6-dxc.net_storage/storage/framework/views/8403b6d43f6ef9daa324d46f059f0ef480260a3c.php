<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-white bg-danger font-weight-bold">Banner Edit</div>
                <div class="card-body" id="content">
                    <form action="<?php echo e(route('admin/banners/update', ['id' => $banner->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control mb-3" id="name" placeholder="Nama Banner" value="<?php echo e($banner->name); ?>">
                                <input type="text" name="url_image" class="form-control mb-3" id="url_image" placeholder="Url Image" value="<?php echo e($banner->url_image); ?>">
                                <select name="is_active" id="is_active" class="form-control">
                                    <?php if($banner->is_active == 1): ?>
                                    <option value="1" selected>Aktif</option>
                                    <option value="0">Tidak Aktif</option>
                                    <?php else: ?>
                                    <option value="1">Aktif</option>
                                    <option value="0" selected>Tidak Aktif</option>
                                    <?php endif; ?>
                                </select>
                                <div class="text-danger mt-2">Ukuran gambar yang diambil dari url baiknya 1170 x 450</div>
                            </div>
                            <div class="col-md-6">
                                <img src="<?php echo e($banner->url_image); ?>" class="img-fluid">
                            </div>
                            <div class="col-md-6 mt-3">
                                <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                                <a class="btn btn-danger btn-sm" href="/admin/banners">Kembali</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/admin/banner/edit.blade.php ENDPATH**/ ?>