<!DOCTYPE html>
<html>
<head>
    <title>Expired Account Member YB6_DXCommunity</title>
</head>
<body style="font-size: 14px; text-align: center;">
	<div>Hello, <?php echo e($data['nama']); ?></div>
	<?php if($data['expired']): ?>
		<div>Your account <?php echo e($data['kategori']); ?> is expired. Please contact <a href="https://yb6-dxc.net/contact-us/" targer="_blank">admin</a> for upgrade</div>
	<?php else: ?>
		<div>Your account <?php echo e($data['kategori']); ?> will be expired 3 months. Please contact <a href="https://yb6-dxc.net/contact-us/" targer="_blank">admin</a> for upgrade</div>
	<?php endif; ?>
    <h1>Callsign : <?php echo e($data['callsign']); ?></h1>
</body>
</html><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/emails/expired.blade.php ENDPATH**/ ?>