<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-white bg-danger font-weight-bold">Award</div>

                <div class="card-body">
                    <a href="<?php echo e(route('admin/awards')); ?>" class="btn btn-danger mb-3">Kembali</a>
                    <form action="<?php echo e(route('admin/award-tambah')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nama">Nama Award</label>
                                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Cth: Award Covid 19">
                                </div>
                                <div class="form-group">
                                    <label for="url_award">Url Award</label>
                                    <input type="text" class="form-control" name="url_award" id="url_award" placeholder="Cth: https://yb6-dxc.net/portfolio/president-bronze-award/">
                                </div>
                                <div class="form-group">
                                    <label for="url_gambar">Url Image</label>
                                    <input type="text" class="form-control" name="url_gambar" id="url_gambar" placeholder="Cth: https://yb6-dxc.net/wp-content/uploads/2020/05/PBA-Award-2.jpg">
                                </div>
                                <div class="form-group">
                                    <label for="category_award">Category Award</label>
                                    <select name="category_award" id="category_award" class="form-control">
                                    	<option value="free">Free</option>
                                    	<option value="premium">Premium</option>
                                    </select>
                                </div>
                                <input type="submit" class="btn btn-primary" value="Submit">
                            </div>
                            <div class="col-md-6 pt-md-4">                                
                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="alert alert-danger alert-dismissible" role="alert">
                                          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                          <?php echo e($error); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/admin/award/create.blade.php ENDPATH**/ ?>