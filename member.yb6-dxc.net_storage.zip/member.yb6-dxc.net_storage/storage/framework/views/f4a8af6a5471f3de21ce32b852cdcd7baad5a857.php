<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-white bg-danger font-weight-bold">Member</div>

                <div class="card-body">
                    <a href="<?php echo e(route('admin/members')); ?>" class="btn btn-danger mb-3">Kembali</a>
                    <button type="button" class="btn btn-success mb-3 float-right" onclick="tambah()">+ Baris</button>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger alert-dismissible" role="alert">
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                      <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <form action="/admin/member/award-store/<?php echo e($id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="300">Nama Award</th>
                                            <th>Link G-Drive Award Member</th>
                                            <th width="10">#</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(!empty($userAwards)): ?>
                                            <?php $__currentLoopData = $userAwards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <select name="award_id[]" class="form-control" required>
                                                            <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($award->id); ?>" <?php echo e(($award->id == $user_award->award_id) ? 'selected' : ''); ?>><?php echo e($award->nama); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <input type="text" class="form-control" name="link_googledrive[]" placeholder="Link google drive award untuk diakses member" value="<?php echo e($user_award->link_googledrive); ?>" required>
                                                    </td>
                                                    <td><button type="button" class="btn btn-danger btn-sm hapus">x</button></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td>
                                                    <select name="award_id[]" class="form-control" required>
                                                        <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($award->id); ?>"><?php echo e($award->nama); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" class="form-control" name="link_googledrive[]" placeholder="Link google drive award untuk diakses member" required>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                            <tr class="table-row"></tr>
                                    </tbody>
                                </table>
                                <input type="submit" class="btn btn-primary float-right" value="Save">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/Javascript">
    function tambah(){
        $('.table-row').after(`
            <tr>
                <td>
                    <select name="award_id[]" class="form-control" required>
                        <?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($award->id); ?>"><?php echo e($award->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
                <td><input type="text" name="link_googledrive[]" class="form-control" placeholder="Link google drive award untuk diakses member" required></td>
                <td><button type="button" class="btn btn-danger btn-sm hapus">x</button></td>
            </tr>
        `)

        hapus()
    }

    function hapus() {
        $('.hapus').click(function(){
            $(this).parent().parent().remove()
        })    
    }

    hapus()
    
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/admin/member/update.blade.php ENDPATH**/ ?>