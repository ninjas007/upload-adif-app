<a href="<?php echo e(url('admin/members')); ?>" class="btn btn-danger mb-3">Kembali</a>
<table class="table">
	<tr>
		<td style="width: 30%">Nama</td><td>:</td><td><?php echo e($user->name); ?></td> <td rowspan="5">
		<img src="<?php echo e(asset('/storage/foto/'.$user->foto)); ?>" width="200" align="right"></td>
	</tr>
	<tr><td style="width: 30%">Email</td><td>:</td><td><?php echo e($user->email); ?></td></tr>
	<tr><td style="width: 30%">Callsign</td><td>:</td><td><?php echo e($user->callsign); ?></td></tr>
	<tr><td style="width: 30%">Kategori</td><td>:</td><td><?php echo e(strtoupper($user->category)); ?></td></tr>
	<?php if($user->category == 'premium'): ?>
	<tr><td style="width: 30%">Class Premium</td><td>:</td><td><?php echo e(strtoupper($user->class_premium)); ?></td></tr>
	<?php endif; ?>
	<tr><td style="width: 30%">Alamat</td><td>:</td><td><?php echo e($user->alamat); ?></td></tr>
</table><?php /**PATH /home/xeojxkjo/member.yb6-dxc.net_storage/resources/views/admin/member/detail.blade.php ENDPATH**/ ?>